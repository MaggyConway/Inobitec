<?
$sSectionName="Dicom Viewer";
?>