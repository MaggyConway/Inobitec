<?
$sSectionName="Продукты";
?>