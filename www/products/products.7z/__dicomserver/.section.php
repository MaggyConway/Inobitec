<?
$sSectionName="Dicom Server";
?>